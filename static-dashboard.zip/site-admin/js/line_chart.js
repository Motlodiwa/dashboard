
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Sales', 'Expenses'],
          ['January',  28,      65],
          ['February',  48,      60],
          ['March',  40,       80],
          ['April',  20,      80],
          ['May',  85,      56]
        ]);

        var options = {
          legend: 'none',
          title: 'Monthly Sales',
          curveType: 'function',
          width: 480,
          height: 400,
          series: {
            0: { color: '#97BBCD' },
            1: { color: '#DCDCDC' }
          }
          
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }