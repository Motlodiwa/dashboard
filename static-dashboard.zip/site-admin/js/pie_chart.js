
google.charts.load("current", {packages:["corechart"]});
google.charts.setOnLoadCallback(drawChart);
function drawChart() {
  var data = google.visualization.arrayToDataTable([
    ['Language', 'Speakers (in millions)'],
    ['English',  80],
    ['French',  20]
  ]);

var options = {
  legend: 'none',
  width: 480,
  height: 400,
  colors: ['#46bfbd','#f7454a'],
  title: 'Support Requests'
};

  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}